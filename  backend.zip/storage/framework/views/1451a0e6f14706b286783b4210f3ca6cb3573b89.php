<h1>Hi, <?php echo e($title); ?></h1>
<p>Sending Mail from Laravel.</p>
