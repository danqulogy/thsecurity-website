<h1>Hi, {{ $title }}</h1>
<p>Sending Mail from Laravel.</p>
